Botwasap v3

Bayak yang baru
Check aja sendiri

|-----------------|

lots of updates
Just check it yourself 
If you can help me to translate the bot language please chat me in whatsapp

|-----------------|

My whatsapp
wa.me/6283893151295

My Instagram
https://Instagram.com/ff_barz
